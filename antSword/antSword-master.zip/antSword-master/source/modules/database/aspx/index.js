//
// 数据库驱动::ASPX
//

module.exports = require('../asp/index');