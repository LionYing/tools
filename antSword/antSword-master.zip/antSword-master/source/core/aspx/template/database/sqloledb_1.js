// 
// ASPX::sqloledb_1数据库驱动代码模板
// 

module.exports = require('./default');